const AWS = require('aws-sdk');

const sns = new AWS.SNS();

exports.handler = async (event) => {

    let email;
    const reqBody = JSON.parse(event.body);
    email = reqBody.email;

    if (!email) {
        throw new Error('No email found');
    }
    
    const params = {
        Protocol: 'email',
        TopicArn: 'arn:aws:sns:us-east-1:836136505875:CustomerOrder',
        Endpoint: email,
    };
    
    try {
        const result = await sns.subscribe(params).promise();
        console.log('Subscription:', result.SubscriptionArn);
        return {
            statusCode: 200,
            body: JSON.stringify('Subscription created successfully!'),
        };
    } catch (error) {
        console.error(error);
        throw new Error('Error creating subscription');
    }
};
